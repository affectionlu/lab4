#include <inc/mmu.h>
#include <inc/x86.h>
#include <inc/assert.h>

#include <kern/pmap.h>
#include <kern/trap.h>
#include <kern/console.h>
#include <kern/monitor.h>
#include <kern/env.h>
#include <kern/syscall.h>
#include <kern/sched.h>
#include <kern/kclock.h>
#include <kern/picirq.h>
#include <kern/cpu.h>
#include <kern/spinlock.h>

// 任务状态段 no longer used
// static struct Taskstate ts;

/* For debugging, so print_trapframe can distinguish between printing
 * a saved trapframe and printing the current trapframe and print some
 * additional information in the latter case.
 */
static struct Trapframe *last_tf;

/* Interrupt descriptor table.  (Must be built at run time because
 * shifted function addresses can't be represented in relocation records.)
 */
// 中断描述符表
struct Gatedesc idt[256] = { { 0 } };
// 中断描述符表寄存器
struct Pseudodesc idt_pd = {
	sizeof(idt) - 1, (uint32_t) idt
};


static const char *trapname(int trapno)
{
	static const char * const excnames[] = {
		"Divide error",
		"Debug",
		"Non-Maskable Interrupt",
		"Breakpoint",
		"Overflow",
		"BOUND Range Exceeded",
		"Invalid Opcode",
		"Device Not Available",
		"Double Fault",
		"Coprocessor Segment Overrun",
		"Invalid TSS",
		"Segment Not Present",
		"Stack Fault",
		"General Protection",
		"Page Fault",
		"(unknown trap)",
		"x87 FPU Floating-Point Error",
		"Alignment Check",
		"Machine-Check",
		"SIMD Floating-Point Exception"
	};

	if (trapno < sizeof(excnames)/sizeof(excnames[0]))
		return excnames[trapno];
	if (trapno == T_SYSCALL)
		return "System call";
	if (trapno >= IRQ_OFFSET && trapno < IRQ_OFFSET + 16)
		return "Hardware Interrupt";
	return "(unknown trap)";
}

// 中断初始化
void
trap_init(void)
{
	extern struct Segdesc gdt[];

	/*
	// Challenge:
	// 外部函数指针数组
	extern void (*funs[])();
	int i;
	//0-19
	for (i = 0; i <= 17; ++i){
		if(i >= 0 && i <= 8){
			if(i == 3){ // T_BRKPT 用户权限
				SETGATE(idt[i], 0, GD_KT, funs[i], 3);
				continue;
			}
			SETGATE(idt[i], 0, GD_KT, funs[i], 0);
		}
		else if (i >=9 && i <= 13) {
			SETGATE(idt[i + 1], 0, GD_KT, funs[i], 0);
		}
		else if (i >=14 && i <= 17) {
			SETGATE(idt[i + 2], 0, GD_KT, funs[i], 0);
		}
	}
	// 其他中断入口点
	SETGATE(idt[T_SYSCALL], 0, GD_KT, funs[i++], 3);
	SETGATE(idt[IRQ_OFFSET + IRQ_TIMER], 0, GD_KT, funs[i++], 0);
	SETGATE(idt[IRQ_OFFSET + IRQ_KBD], 0, GD_KT, funs[i++], 0);
	SETGATE(idt[IRQ_OFFSET + IRQ_SERIAL], 0, GD_KT, funs[i++], 0);
	SETGATE(idt[IRQ_OFFSET + IRQ_SPURIOUS], 0, GD_KT, funs[i++], 0);
	SETGATE(idt[IRQ_OFFSET + IRQ_IDE], 0, GD_KT, funs[i++], 0);
	SETGATE(idt[IRQ_OFFSET + IRQ_ERROR], 0, GD_KT, funs[i++], 0);
	*/

	extern void divide_entry();
    extern void debug_entry();
    extern void nmi_entry();
    extern void brkpt_entry();
    extern void oflow_entry();
    extern void bound_entry();
    extern void illop_entry();
    extern void device_entry();
    extern void dblflt_entry();
    extern void tss_entry();
    extern void segnp_entry();
    extern void stack_entry();
    extern void gpflt_entry();
    extern void pgflt_entry();
    extern void fperr_entry();
    extern void align_entry();
    extern void mchk_entry();
    extern void simderr_entry();
    extern void syscall_entry();

	// ---------------lab4
	// set IDT for IRQ handler
	extern void routine_irq0();
	extern void routine_irq1();
	extern void routine_irq2();
	extern void routine_irq3();
	extern void routine_irq4();
	extern void routine_irq5();
	extern void routine_irq6();
	extern void routine_irq7();
	extern void routine_irq8();
	extern void routine_irq9();
	extern void routine_irq10();
	extern void routine_irq11();
	extern void routine_irq12();
	extern void routine_irq13();
	extern void routine_irq14();
	extern void routine_irq15();

        SETGATE(idt[T_DIVIDE], 0, GD_KT, divide_entry, 0);
        SETGATE(idt[T_DEBUG], 0, GD_KT, debug_entry, 0);
        SETGATE(idt[T_NMI], 0, GD_KT, nmi_entry, 0);
        SETGATE(idt[T_BRKPT], 0, GD_KT, brkpt_entry, 3);
        SETGATE(idt[T_OFLOW], 0, GD_KT, oflow_entry, 0);
        SETGATE(idt[T_BOUND], 0, GD_KT, bound_entry, 0);
        SETGATE(idt[T_ILLOP], 0, GD_KT, illop_entry, 0);
        SETGATE(idt[T_DEVICE], 0, GD_KT, device_entry, 0);
        SETGATE(idt[T_DBLFLT], 0, GD_KT, dblflt_entry, 0);
        SETGATE(idt[T_TSS], 0, GD_KT, tss_entry, 0);
        SETGATE(idt[T_SEGNP], 0, GD_KT, segnp_entry, 0);
        SETGATE(idt[T_STACK], 0, GD_KT, stack_entry, 0);
        SETGATE(idt[T_GPFLT], 0, GD_KT, gpflt_entry, 0);
        SETGATE(idt[T_PGFLT], 0, GD_KT, pgflt_entry, 0);
        SETGATE(idt[T_FPERR], 0, GD_KT, fperr_entry, 0);
        SETGATE(idt[T_ALIGN], 0, GD_KT, align_entry, 0);
        SETGATE(idt[T_MCHK], 0, GD_KT, mchk_entry, 0);
        SETGATE(idt[T_SIMDERR], 0, GD_KT, simderr_entry, 0);
        SETGATE(idt[T_SYSCALL], 0, GD_KT, syscall_entry, 3);

	// -----------------lab4
	SETGATE(idt[IRQ_OFFSET+0],0,GD_KT,routine_irq0,0);
	SETGATE(idt[IRQ_OFFSET+1],0,GD_KT,routine_irq1,0);
	SETGATE(idt[IRQ_OFFSET+2],0,GD_KT,routine_irq2,0);
	SETGATE(idt[IRQ_OFFSET+3],0,GD_KT,routine_irq3,0);
	SETGATE(idt[IRQ_OFFSET+4],0,GD_KT,routine_irq4,0);
	SETGATE(idt[IRQ_OFFSET+5],0,GD_KT,routine_irq5,0);
	SETGATE(idt[IRQ_OFFSET+6],0,GD_KT,routine_irq6,0);
	SETGATE(idt[IRQ_OFFSET+7],0,GD_KT,routine_irq7,0);
	SETGATE(idt[IRQ_OFFSET+8],0,GD_KT,routine_irq8,0);
	SETGATE(idt[IRQ_OFFSET+9],0,GD_KT,routine_irq9,0);
	SETGATE(idt[IRQ_OFFSET+10],0,GD_KT,routine_irq10,0);
	SETGATE(idt[IRQ_OFFSET+11],0,GD_KT,routine_irq11,0);
	SETGATE(idt[IRQ_OFFSET+12],0,GD_KT,routine_irq12,0);
	SETGATE(idt[IRQ_OFFSET+13],0,GD_KT,routine_irq13,0);
	SETGATE(idt[IRQ_OFFSET+14],0,GD_KT,routine_irq14,0);
	SETGATE(idt[IRQ_OFFSET+15],0,GD_KT,routine_irq15,0);
	// Per-CPU setup
	trap_init_percpu();
}

// Initialize and load the per-CPU TSS and IDT
// 为各个CPU初始化和加载TSS与IDT
void
trap_init_percpu(void)
{
	// The example code here sets up the Task State Segment (TSS) and
	// the TSS descriptor for CPU 0. But it is incorrect if we are
	// running on other CPUs because each CPU has its own kernel stack.
	// Fix the code so that it works for all CPUs.
	/*
	 * 示例代码设置了 CPU 0 的任务状态段及其描述符
	 * 但运行其他CPU时则不正确，因为每个CPU有自己的内核栈
	 */
	// Hints:
	//   - The macro "thiscpu" always refers to the current CPU's
	//     struct CpuInfo;
	//   - The ID of the current CPU is given by cpunum() or
	//     thiscpu->cpu_id;
	//   - Use "thiscpu->cpu_ts" as the TSS for the current CPU,
	//     rather than the global "ts" variable;
	//   - Use gdt[(GD_TSS0 >> 3) + i] for CPU i's TSS descriptor;
	//   - You mapped the per-CPU kernel stacks in mem_init_mp()
	/*
	 * 提示:
	 * 	 - 宏定义 thiscpu 总指向当前CPU信息结果变量
	 * 	 - 当前CPU ID可以通过 cpunum() 或 thiscpu->cpu_id 获得
	 * 	 - 使用 thiscpu->cpu_ts 作为当前CPU的 TSS 而不是 ts
	 * 	 - 使用 gdt[(GD_TSS0 >> 3) + i] 作为各个CPU的TSS描述符
	 */
	// ltr sets a 'busy' flag in the TSS selector, so if you
	// accidentally load the same TSS on more than one CPU, you'll
	// get a triple fault.  If you set up an individual CPU's TSS
	// wrong, you may not get a fault until you try to return from
	// user space on that CPU.
	/*
	 * ltr 指令会将TSS选择子设置占用，所以，
	 * 如果你为多个CPU装载同一个TSS，你会得到一个三倍错误
	 * 如果你错误的设置了一个CPU的TSS，那么当你试图在此CPU中从用户空间返回时，
	 * 可能会得到错误。
	 */
	// LAB 4: Your code here:

	// Setup a TSS so that we get the right stack
	// when we trap to the kernel.
	// 内核栈顶：KSTACKTOP
	// 内核数据段：GD_KD

	int current_cpu_id = thiscpu->cpu_id; // 获得当前CPU ID
	thiscpu->cpu_ts.ts_esp0 = KSTACKTOP - current_cpu_id * (KSTKSIZE + KSTKGAP); // 当前CPU所处的堆栈
	thiscpu->cpu_ts.ts_ss0 = GD_KD;

	// Initialize the TSS slot of the gdt.
	// 初始化GDT中的TSS符 每项占8字节
	gdt[(GD_TSS0 >> 3) + current_cpu_id] = SEG16(STS_T32A, (uint32_t) (&thiscpu->cpu_ts), sizeof(struct Taskstate) - 1, 0);
	gdt[(GD_TSS0 >> 3) + current_cpu_id].sd_s = 0;

	// Load the TSS selector (like other segment selectors, the
	// bottom three bits are special; we leave them 0)
	// 加载TSS寄存器
	ltr(GD_TSS0 + 8 * current_cpu_id); // 每项占8字节

	// Load the IDT
	// 加载IDT寄存器
	lidt(&idt_pd);
}

void
print_trapframe(struct Trapframe *tf)
{
	cprintf("TRAP frame at %p from CPU %d\n", tf, cpunum());
	print_regs(&tf->tf_regs);
	cprintf("  es   0x----%04x\n", tf->tf_es);
	cprintf("  ds   0x----%04x\n", tf->tf_ds);
	cprintf("  trap 0x%08x %s\n", tf->tf_trapno, trapname(tf->tf_trapno));
	// If this trap was a page fault that just happened
	// (so %cr2 is meaningful), print the faulting linear address.
	if (tf == last_tf && tf->tf_trapno == T_PGFLT)
		cprintf("  cr2  0x%08x\n", rcr2());
	cprintf("  err  0x%08x", tf->tf_err);
	// For page faults, print decoded fault error code:
	// U/K=fault occurred in user/kernel mode
	// W/R=a write/read caused the fault
	// PR=a protection violation caused the fault (NP=page not present).
	if (tf->tf_trapno == T_PGFLT)
		cprintf(" [%s, %s, %s]\n",
			tf->tf_err & 4 ? "user" : "kernel",
			tf->tf_err & 2 ? "write" : "read",
			tf->tf_err & 1 ? "protection" : "not-present");
	else
		cprintf("\n");
	cprintf("  eip  0x%08x\n", tf->tf_eip);
	cprintf("  cs   0x----%04x\n", tf->tf_cs);
	cprintf("  flag 0x%08x\n", tf->tf_eflags);
	if ((tf->tf_cs & 3) != 0) {
		cprintf("  esp  0x%08x\n", tf->tf_esp);
		cprintf("  ss   0x----%04x\n", tf->tf_ss);
	}
}

void
print_regs(struct PushRegs *regs)
{
	cprintf("  edi  0x%08x\n", regs->reg_edi);
	cprintf("  esi  0x%08x\n", regs->reg_esi);
	cprintf("  ebp  0x%08x\n", regs->reg_ebp);
	cprintf("  oesp 0x%08x\n", regs->reg_oesp);
	cprintf("  ebx  0x%08x\n", regs->reg_ebx);
	cprintf("  edx  0x%08x\n", regs->reg_edx);
	cprintf("  ecx  0x%08x\n", regs->reg_ecx);
	cprintf("  eax  0x%08x\n", regs->reg_eax);
}

// 分发中断处理，分别进行各自的处理
static void
trap_dispatch(struct Trapframe *tf)
{
	// Handle spurious interrupts
	// The hardware sometimes raises these because of noise on the
	// IRQ line or other reasons. We don't care.
	if (tf->tf_trapno == IRQ_OFFSET + IRQ_SPURIOUS) {
		cprintf("Spurious interrupt on irq 7\n");
		print_trapframe(tf);
		return;
	}
	// Handle processor exceptions.
	// LAB 3: Your code here.
	// Handle clock interrupts. Don't forget to acknowledge the
	// interrupt using lapic_eoi() before calling the scheduler!
	// LAB 4: Your code here.
	// Handle keyboard and serial interrupts.
	// LAB 5: Your code here.
	int ret;
	switch(tf->tf_trapno){
		case T_PGFLT:
			page_fault_handler(tf);
			return;
		case T_BRKPT:
	        monitor(tf);
	        return;
		case T_DEBUG:
		    monitor_jdb(tf);
		    return;
		case T_SYSCALL:
			ret = syscall(
					tf->tf_regs.reg_eax,
			        tf->tf_regs.reg_edx,
			        tf->tf_regs.reg_ecx,
			        tf->tf_regs.reg_ebx,
			        tf->tf_regs.reg_edi,
			        tf->tf_regs.reg_esi);
			tf->tf_regs.reg_eax = ret;
			return;
		case IRQ_OFFSET + IRQ_TIMER:
		    lapic_eoi();
		    sched_yield();
		    return;
		case IRQ_OFFSET + IRQ_KBD:
			kbd_intr();
			return;
		case IRQ_OFFSET + IRQ_SERIAL:
			serial_intr();
			return;
	}
	// Unexpected trap: The user process or the kernel has a bug.
	print_trapframe(tf);
	if (tf->tf_cs == GD_KT)
		panic("unhandled trap in kernel");
	else {
		env_destroy(curenv);
		return;
	}
}

void
trap(struct Trapframe *tf)
{
	// The environment may have set DF and some versions
	// of GCC rely on DF being clear
	// DF复位为0,内存向高地址增长
	asm volatile("cld" ::: "cc");

	// Halt the CPU if some other CPU has called panic()
	extern char *panicstr;
	if (panicstr)
		asm volatile("hlt");

	// Re-acqurie the big kernel lock if we were halted in
	// sched_yield()
	if (xchg(&thiscpu->cpu_status, CPU_STARTED) == CPU_HALTED)
		lock_kernel();
	// Check that interrupts are disabled.  If this assertion
	// fails, DO NOT be tempted to fix it by inserting a "cli" in
	// the interrupt path.
	// 判断IF位是否置0,屏蔽其他中断
	assert(!(read_eflags() & FL_IF));

	// lab 3, lab 4 注释掉
//	cprintf("Incoming TRAP frame at %p\n", tf);

	// 用户模式
	if ((tf->tf_cs & 3) == 3) {
		// Trapped from user mode.
		// Acquire the big kernel lock before doing any
		// serious kernel work.
		// LAB 4: Your code here.
		lock_kernel(); // 上锁
		assert(curenv);

		// Garbage collect if current enviroment is a zombie
		if (curenv->env_status == ENV_DYING) {
			env_free(curenv);
			curenv = NULL;
			sched_yield();
		}

		// Copy trap frame (which is currently on the stack)
		// into 'curenv->env_tf', so that running the environment
		// will restart at the trap point.
		// 更新tf段
		curenv->env_tf = *tf;
		// The trapframe on the stack should be ignored from here on.
		tf = &curenv->env_tf;
	}

	// Record that tf is the last real trapframe so
	// print_trapframe can print some additional information.
	// 更新last_tf，以便打印出其他信息
	last_tf = tf;

	// Dispatch based on what type of trap occurred
	// 中断分发机制
	trap_dispatch(tf);

	// If we made it to this point, then no other environment was
	// scheduled, so we should return to the current environment
	// if doing so makes sense.
	if (curenv && curenv->env_status == ENV_RUNNING)
		env_run(curenv);
	else
		sched_yield();
//=======
	// Return to the current environment, which should be running.
	// 系统调用结束，返回用户模式
	assert(curenv && curenv->env_status == ENV_RUNNING);
	env_run(curenv);
//>>>>>>> lab3
}

/*
 * 缺页分发处理函数
 */
void
page_fault_handler(struct Trapframe *tf)
{
	uint32_t fault_va;

	// Read processor's CR2 register to find the faulting address
	// CR2是页故障线性地址寄存器，保存最后一次出现页故障的全32位线性地址
	fault_va = rcr2();

	// Handle kernel-mode page faults.
	// 处理内核模式下的页故障
	// LAB 3: Your code here.
	if (tf->tf_cs == GD_KT) {
		panic("page_fault_handler: page fault in kernel mode");
	}

	// We've already handled kernel-mode exceptions, so if we get here,
	// the page fault happened in user mode.
	// 我们已经解决内核模式异常，因此如果到达此处，说明页故障发生在用户模式
	// 接下来在 lab 4 中将要对这一部分进行处理

	// Call the environment's page fault upcall, if one exists.  Set up a
	// page fault stack frame on the user exception stack (below
	// UXSTACKTOP), then branch to curenv->env_pgfault_upcall.
	/*
	 * 如果存在进程缺页处理函数，则调用它。
	 * 在用户异常栈中设置一个缺页栈结构，处于 UXSTACKTOP 之下，
	 * 之后转向 curenv->env_pgfault_upcall，进行处理。
	 */
	// The page fault upcall might cause another page fault, in which case
	// we branch to the page fault upcall recursively, pushing another
	// page fault stack frame on top of the user exception stack.
	/*
	 * 缺页处理函数可能会引起另外一个缺页错误，在这种情况下，我们递归的转向该缺页处理函数，
	 * 继续向用户异常栈中压入一个缺页栈结构。
	 */
	// The trap handler needs one word of scratch space at the top of the
	// trap-time stack in order to return.  In the non-recursive case, we
	// don't have to worry about this because the top of the regular user
	// stack is free.  In the recursive case, this means we have to leave
	// an extra word between the current top of the exception stack and
	// the new stack frame because the exception stack _is_ the trap-time
	// stack.
	/*
	 * 陷阱处理程序需要在 trap-time 栈的顶部位置获得4字节的暂存空间用于返回。
	 * 在非递归的情况下，我们不用担心这种状态，因为正常用户栈的顶部是空闲的。
	 * 在递归的情况下，这意味着我们必须在当前异常栈的顶部和新栈之间保留额外的4字节空间，
	 * 因为异常栈进入了 trap-time 状态，需要保留用于递归调用。
	 * 为什么需要保留4字节用于递归调用呢？
	 * 		个人分析：正常情况下的函数调用发生在同一个栈中，过程为：
	 * 				参数入栈、返回地址入栈，ebp入栈和栈桢切换和代码跳转。
	 */
	// If there's no page fault upcall, the environment didn't allocate a
	// page for its exception stack or can't write to it, or the exception
	// stack overflows, then destroy the environment that caused the fault.
	// Note that the grade script assumes you will first check for the page
	// fault upcall and print the "user fault va" message below if there is
	// none.  The remaining three checks can be combined into a single test.
	/*
	 * 如果不存在缺页处理函数，进程就不用为它的异常栈分配页或者不能写入，
	 * 或者异常栈溢出时，只用销毁引起缺页的进程即可。
	 * 注意打分程序假设你会首先检查缺页处理函数，如果不存在，会打印出 "user fault va" 信息。
	 * 剩下的三个 check 程序可以被合并为一个单独的测试。
	 */
	// Hints:
	//   user_mem_assert() and env_run() are useful here.
	//   To change what the user environment runs, modify 'curenv->env_tf'
	//   (the 'tf' variable points at 'curenv->env_tf').
	/*
	 * 提示：
	 * 	user_mem_assert 和 env_run 函数需要被使用到。
	 * 	为了改变运行进程的执行，修改 curenv->env_tf(tf) 即可
	 */
	// LAB 4: Your code here.
	struct UTrapframe *utf; // 用户陷阱栈结构
	uintptr_t utf_addr; // 桢结构地址
	if (curenv->env_pgfault_upcall) { // 缺页处理函数存在
		// 在用户异常栈中压入一个缺页栈结构
		if ((tf->tf_esp >= UXSTACKTOP - PGSIZE) && (tf->tf_esp < UXSTACKTOP))
			utf_addr = tf->tf_esp - sizeof(struct UTrapframe) - 4; // 缺页处理函数引起另一个缺页
		else
	        utf_addr = UXSTACKTOP - sizeof(struct UTrapframe); // 第一次缺页
		 // 检查进程是否用权限访问指定的内存，或者是否溢出，空间不足
	    user_mem_assert(curenv, (const void *)utf_addr, sizeof(struct UTrapframe), PTE_P | PTE_W);
	    // 均符合，获得压入栈的位置，将异常栈结构压入
	    utf = (struct UTrapframe*)utf_addr;
	    utf->utf_fault_va = fault_va;
	    utf->utf_err = tf->tf_err;
	    utf->utf_regs = tf->tf_regs;
	    utf->utf_eip = tf->tf_eip;
	    utf->utf_eflags = tf->tf_eflags;
	    utf->utf_esp = tf->tf_esp; // 此处的esp为用户栈的esp或上一个缺页处理函数所在用户异常栈的esp，用于缺页处理函数返回
	    // 之后，跳转执行缺页处理函数，eip指向了缺页处理函数
	    curenv->env_tf.tf_eip = (uintptr_t)curenv->env_pgfault_upcall;
	    curenv->env_tf.tf_esp = utf_addr;
	    env_run(curenv);
	    }
	// Destroy the environment that caused the fault.
	// 不符合上述条件，销毁引起故障的进程
	cprintf("[%08x] user fault va %08x ip %08x\n",
		curenv->env_id, fault_va, tf->tf_eip);
	print_trapframe(tf);
	env_destroy(curenv);
}
/*
 * UXSTACKTOP ------>  +------------------------------+ 0xeec00000 ------------+
 *  			       |          UTrapframe          |                        |
 *                     |           NULL-4B            |                        |
 *                     |          UTrapframe          |                        |
 *                     |           NULL-4B            |上一个缺页处理函数触发缺页位置|
 *                     +------------------------------+--+                     |
 *                     |        trap-time esp    	  |  |                     |
 *                     |       trap-time eflags	      |  |                     |
 *                     |        trap-time eip		  |  |                     |
 *                     |        trap-time eax 		  |  |                     |
 *                     |        trap-time ecx         |  |                     |
 *                     |  		trap-time edx		  |  |                     |
 *                     | 		trap-time ebx		  |  |-->UTrapframe        |--> User Exception Stack RW/RW PGSIZE
 *                     | 		trap-time esp		  |  |                     |
 *                     |  		trap-time ebp		  |  |                     |
 *                     |  		trap-time esi		  |  |                     |
 *                     |  		trap-time edi		  |  |                     |
 *                     |      tf_err(error code)	  |  |                     |
 *                     |  		  fault_va	    	  |  |                     |
 *                     +------------------------------+--+                     |
 *                     |           NULL-4B            |                        |
 *                     |          UTrapframe          |                        |
 *                     |             ...              |                        |
 *                     +------------------------------+ 0xeebff000 ------------+
 *                     |       Empty Memory (*)       | --/--  PGSIZE
 * USTACKTOP ------->  +------------------------------+ 0xeebfe000
 *                     |      Normal User Stack       | RW/RW  PGSIZE
 *                     +------------------------------+ 0xeebfd000
 */
