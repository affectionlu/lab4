#ifndef JOS_INC_SPINLOCK_H
#define JOS_INC_SPINLOCK_H

#include <inc/types.h>

// Comment this to disable spinlock debugging
#define DEBUG_SPINLOCK

// Mutual exclusion lock. 互斥锁 —— 自旋锁
struct spinlock {
	unsigned locked;       // Is the lock held?

#ifdef DEBUG_SPINLOCK
	// For debugging:
	char *name;            // Name of lock. 锁名
	struct CpuInfo *cpu;   // The CPU holding the lock. 获得锁的CPU
	uintptr_t pcs[10];     // The call stack (an array of program counters)
	                       // that locked the lock. 调用锁的栈，程序计数器数组
#endif
};

void __spin_initlock(struct spinlock *lk, char *name); // 自旋锁初始化
void spin_lock(struct spinlock *lk); // 自旋锁上锁
void spin_unlock(struct spinlock *lk); // 自旋锁开锁

// 自旋锁初始化
#define spin_initlock(lock)   __spin_initlock(lock, #lock)

// 全局自旋锁
extern struct spinlock kernel_lock;

// 全局自旋锁上锁
static inline void
lock_kernel(void)
{
	spin_lock(&kernel_lock);
}

// 全局自旋锁开锁
static inline void
unlock_kernel(void)
{
	spin_unlock(&kernel_lock);

	// Normally we wouldn't need to do this, but QEMU only runs
	// one CPU at a time and has a long time-slice.  Without the
	// pause, this CPU is likely to reacquire the lock before
	// another CPU has even been given a chance to acquire it.
	/*
	 * 正常情况下我们不必加解锁，但是QEMU一次仅运行一个CPU而且长等待(长时间片)
	 * 如果没有 pause，当前的CPU很可能在其他CPU得到获得锁的机会前再次获得锁。
	 */
	asm volatile("pause");
}

#endif
