/* See COPYRIGHT for copyright information. */

#include <inc/x86.h>
#include <inc/error.h>
#include <inc/string.h>
#include <inc/assert.h>

#include <kern/env.h>
#include <kern/pmap.h>
#include <kern/trap.h>
#include <kern/syscall.h>
#include <kern/console.h>
#include <kern/sched.h>

// Print a string to the system console.
// The string is exactly 'len' characters long.
// Destroys the environment on memory errors.
static void
sys_cputs(const char *s, size_t len)
{
	// Check that the user has permission to read memory [s, s+len).
	// Destroy the environment if not.

	// LAB 3: Your code here.
	user_mem_assert(curenv, (void *)s, len, 0);

	// Print the string supplied by the user.
	cprintf("%.*s", len, s);
}

// Read a character from the system console without blocking.
// Returns the character, or 0 if there is no input waiting.
static int
sys_cgetc(void)
{
	return cons_getc();
}

// Returns the current environment's envid.
static envid_t
sys_getenvid(void)
{
	return curenv->env_id;
}

// Destroy a given environment (possibly the currently running environment).
//
// Returns 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
static int
sys_env_destroy(envid_t envid)
{
	int r;
	struct Env *e;

	if ((r = envid2env(envid, &e, 1)) < 0)
		return r;
	env_destroy(e);
	return 0;
}

// Deschedule current environment and pick a different one to run.
static void
sys_yield(void)
{
	sched_yield();
}

// Allocate a new environment.
// Returns envid of new environment, or < 0 on error.  Errors are:
//	-E_NO_FREE_ENV if no free environment is available.
//	-E_NO_MEM on memory exhaustion.
/*
 * 创建新进程，返回进程号，错误则返回负数
 * 错误：
 * 	- 无空闲进程可用，返回E_NO_FREE_ENV
 * 	- 无可用内存，返回E_NO_MEM
 */
static envid_t
sys_exofork(void)
{
	// Create the new environment with env_alloc(), from kern/env.c.
	// It should be left as env_alloc created it, except that
	// status is set to ENV_NOT_RUNNABLE, and the register set is copied
	// from the current environment -- but tweaked so sys_exofork
	// will appear to return 0.
	/*
	 * 使用 env_alloc() 创建一个新进程
	 * 它的状态应该和创建以后一样，直到状态变为 ENV_NOT_RUNNABLE
	 * 新进程的寄存器状态和父进程一样
	 * 但是在子进程中 sys_exofork 应该返回0
	 * 因为子进程开始时被标记为不可运行，sys_exofork 并不会真的返回到子进程，
	 * 除非父进程显式地将其标记为可以运行以允许子进程运行
	 */
	// LAB 4: Your code here.
//	panic("sys_exofork not implemented");
    struct Env * child_env;
    int error_code;
    if ((error_code = env_alloc(&child_env, curenv->env_id)) < 0)
        return error_code; // 错误码
    child_env->env_tf = curenv->env_tf; // 子进程寄存器和父进程一样
    child_env->env_status = ENV_NOT_RUNNABLE; // 状态为不可运行
    child_env->env_tf.tf_regs.reg_eax = 0;
    return child_env->env_id; // 返回进程号
}

// Set envid's env_status to status, which must be ENV_RUNNABLE
// or ENV_NOT_RUNNABLE.
//
// Returns 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
//	-E_INVAL if status is not a valid status for an environment.
/*
 * 将指定进程的状态设置为指定状态，必须是 ENV_RUNNABLE 与 ENV_NOT_RUNNABLE 之一
 * 成功则返回0，小于0为错误
 *  -E_BAD_ENV，进程不存在或者无权限
 *  -E_INVAL，状态无效
 */
static int
sys_env_set_status(envid_t envid, int status)
{
	// Hint: Use the 'envid2env' function from kern/env.c to translate an
	// envid to a struct Env.
	// You should set envid2env's third argument to 1, which will
	// check whether the current environment has permission to set
	// envid's status.
	/*
	 * 提示：
	 * 	使用 envid2env 函数将进程号转换为进程指针
	 * 	将 envid2env 的第三个参数设置为1，检查是否具有权限
	 */
	// LAB 4: Your code here.
//	panic("sys_env_set_status not implemented");
    struct Env *env_store;
    int errorcode;
    if ((errorcode = envid2env(envid, &env_store, 1)) < 0)
        return errorcode; // 无权限 envid2env 返回 -E_BAD_ENV
    if (status != ENV_RUNNABLE && status != ENV_NOT_RUNNABLE)
        return -E_INVAL;
    env_store->env_status = status;
    return 0;
}

// Set envid's trap frame to 'tf'.
// tf is modified to make sure that user environments always run at code
// protection level 3 (CPL 3) with interrupts enabled.
//
// Returns 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
/*
 * 将指定进程的栈桢结构设置为 tf
 * uh 会被修改，确保用户金策划嗯一直运行在级别3，且打开中断
 *
 * 返回：
 * 		0：成功，<0：失败
 * 		-E_BAD_ENV，进程不存在或无权限
 */
static int
sys_env_set_trapframe(envid_t envid, struct Trapframe *tf)
{
	// LAB 5: Your code here.
	// Remember to check whether the user has supplied us with a good
	// address!
//	panic("sys_env_set_trapframe not implemented");
	struct Env *env;
	int r = envid2env(envid, &env, 1); // 进程不存在或无权限
	if(r != 0)
		return r;
	env->env_tf = *tf;
	env->env_tf.tf_eflags |= FL_IF; // 允许中断
	return 0;
}

// Set the page fault upcall for 'envid' by modifying the corresponding struct
// Env's 'env_pgfault_upcall' field.  When 'envid' causes a page fault, the
// kernel will push a fault record onto the exception stack, then branch to
// 'func'.
//
// Returns 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
/*
 * 通过赋值进程结构体中的 env_pgfault_upcall 变量，设置缺页处理函数(调用)，便于进程使用。
 * 当进程触发页错误时，内核将会将错误记录压栈，然后转向执行指定的函数。
 *
 * 执行成功返回0,错误返回值小于0：
 * 	-E_BAD_ENV，进程不存在，或者调用者无权限
 */
static int
sys_env_set_pgfault_upcall(envid_t envid, void *func)
{
	// LAB 4: Your code here.
//	panic("sys_env_set_pgfault_upcall not implemented");
    struct Env *env_store;
    if (envid2env(envid, &env_store, 1) < 0) // 进程不存在或者无权限，envid2env负责检查
        return -E_BAD_ENV;
    env_store->env_pgfault_upcall = func; // 缺页处理函数
    return 0;
}

// Allocate a page of memory and map it at 'va' with permission
// 'perm' in the address space of 'envid'.
// The page's contents are set to 0.
// If a page is already mapped at 'va', that page is unmapped as a
// side effect.
//
// perm -- PTE_U | PTE_P must be set, PTE_AVAIL | PTE_W may or may not be set,
//         but no other bits may be set.  See PTE_SYSCALL in inc/mmu.h.
//
// Return 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
//	-E_INVAL if va >= UTOP, or va is not page-aligned.
//	-E_INVAL if perm is inappropriate (see above).
//	-E_NO_MEM if there's no memory to allocate the new page,
//		or to allocate any necessary page tables.
/*
 * 为指定进程分配一个内存页，同时将其和虚拟地址va映射起来，设置属性perm。
 * 该页的目录设置为0。
 * 如果已经有页映射到va，这个新页则不会被映射，成为边缘效应
 *
 * perm —— PTE_U | PTE_P 必须设置，PTE_AVAIL | PTE_W 可能会设置
 *
 * 返回0表示成功，小于0表示出错：
 *  -E_BAD_ENV，进程不存在，或者当前进程无权限更改
 *  -E_INVAL，虚拟地址溢出——大于等于UTOP，或虚拟地址未对齐，或给定属性值不正确
 *  -E_NO_MEM，无可用内存可供分配给页或页表
 */
static int
sys_page_alloc(envid_t envid, void *va, int perm)
{
	// Hint: This function is a wrapper around page_alloc() and
	//   page_insert() from kern/pmap.c.
	//   Most of the new code you write should be to check the
	//   parameters for correctness.
	//   If page_insert() fails, remember to free the page you
	//   allocated!
	/*
	 * 提示：
	 * 	该函数是对 page_alloc 和 page_insert 的包装。
	 * 	你所写的大多数代码应该检查参数是否正确
	 * 	如果 page_insert 失败，记得释放分配的页
	 */
	// LAB 4: Your code here.
//	panic("sys_page_alloc not implemented");
    struct Env *env_store; // 指定进程
    struct PageInfo * ppg; // 页信息
    int flag = PTE_P | PTE_U; // 固定属性，必须设置
    if (envid2env(envid, &env_store, 1) < 0) // 进程号转换为进程失败
        return -E_BAD_ENV;
    if (((uintptr_t)va >= UTOP) || PGOFF(va) || ((perm & flag) != flag)) // va溢出或未对齐(地址偏移量不等于0)，或属性不正确
           return -E_INVAL;
    if (perm & ~(PTE_SYSCALL)) // 属性不正确 #define PTE_SYSCALL	(PTE_AVAIL | PTE_P | PTE_W | PTE_U) 除了这几位，其他不能设置，见上面要求
        return -E_INVAL;
    if ((ppg = page_alloc(ALLOC_ZERO)) == NULL) // 分配新页
        return -E_NO_MEM;
//    ppg->pp_ref++; // 映射计数加一，此处不必，page_insert时会自动加
    if (page_insert(env_store->env_pgdir, ppg, va, perm) < 0) { // va已经被映射
        page_free(ppg);
        return -E_NO_MEM;
    }
    return 0;
}

// Map the page of memory at 'srcva' in srcenvid's address space
// at 'dstva' in dstenvid's address space with permission 'perm'.
// Perm has the same restrictions as in sys_page_alloc, except
// that it also must not grant write access to a read-only
// page.
//
// Return 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if srcenvid and/or dstenvid doesn't currently exist,
//		or the caller doesn't have permission to change one of them.
//	-E_INVAL if srcva >= UTOP or srcva is not page-aligned,
//		or dstva >= UTOP or dstva is not page-aligned.
//	-E_INVAL is srcva is not mapped in srcenvid's address space.
//	-E_INVAL if perm is inappropriate (see sys_page_alloc).
//	-E_INVAL if (perm & PTE_W), but srcva is read-only in srcenvid's
//		address space.
//	-E_NO_MEM if there's no memory to allocate any necessary page tables.
/*
 * 将两个进程中各自指定的虚拟地址映射起来，设置属性perm
 * perm具有和sys_page_alloc中的一样限制，另外写权限永远不能访问只读权限页面
 *  -E_BAD_ENV，两个进程之一或均不存在，或者当前进程无权限更改
 *  -E_INVAL，虚拟地址溢出——大于等于UTOP，或虚拟地址未对齐，或给定属性值不正确
 *  		或者perm是写权限，而srcva是只读权限
 *  -E_NO_MEM，无可用内存可供分配给页或页表
 */
static int
sys_page_map(envid_t srcenvid, void *srcva,
	     envid_t dstenvid, void *dstva, int perm)
{
	// Hint: This function is a wrapper around page_lookup() and
	//   page_insert() from kern/pmap.c.
	//   Again, most of the new code you write should be to check the
	//   parameters for correctness.
	//   Use the third argument to page_lookup() to
	//   check the current permissions on the page.
	/*
	 * 提示：
	 * 	该函数应该是 page_lookup 和 page_insert 的封装使用
	 * 	你所写的大多数代码应该检查参数是否正确
	 */
	// LAB 4: Your code here.
//	panic("sys_page_map not implemented");
    struct Env *env_src, *env_dst; // 源进程，目的进程
    struct PageInfo * ppg; // 新页
    pte_t *ppte; // 页表项
    int errorcode;
    int flag = PTE_P | PTE_U;
    if ((envid2env(srcenvid, &env_src, 1) < 0) || (envid2env(dstenvid, &env_dst, 1) < 0)) // 进程不存在或无权限
        return -E_BAD_ENV;
    if (((uintptr_t)srcva >= UTOP) || PGOFF(srcva) || ((uintptr_t)dstva >= UTOP) || PGOFF(dstva)) // 溢出，或未对齐，及偏移量不等于0
        return -E_INVAL;
    if ((ppg = page_lookup(env_src->env_pgdir, srcva, &ppte)) == NULL) // 查找源进程指定地址的页
        return -E_INVAL;
    if ((perm & ~(PTE_SYSCALL)) || ((perm & flag) != flag)) // 权限不正确
        return -E_INVAL;
    if ((perm & PTE_W) && !(*ppte & PTE_W)) // 指定页只读，而权限为可写
        return -E_INVAL;
    if (page_insert(env_dst->env_pgdir, ppg, dstva, perm) < 0) // 将目的进程指定的虚拟地址与查找到的页映射起来
        return -E_NO_MEM;
    return 0;
}

// Unmap the page of memory at 'va' in the address space of 'envid'.
// If no page is mapped, the function silently succeeds.
//
// Return 0 on success, < 0 on error.  Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist,
//		or the caller doesn't have permission to change envid.
//	-E_INVAL if va >= UTOP, or va is not page-aligned.
/*
 * 取消指定进程指定页的映射
 * 如果该页还未映射，必然成功
 *
 * 成功则返回0，错误返回负数：
 * 	-E_BAD_ENV，进程不存在，或当前进程无权限操作
 * 	-E_INVAL，va溢出或未对齐
 */
static int
sys_page_unmap(envid_t envid, void *va)
{
	// Hint: This function is a wrapper around page_remove().
	// 提示：该函数可使用 page_remove
	// LAB 4: Your code here.
//	panic("sys_page_unmap not implemented");
    struct Env *env_store;
    struct PageInfo *pp;
    if (envid2env(envid, &env_store, 1) < 0) // 进程不存在或无权限
        return -E_BAD_ENV;
    if (((uintptr_t)va >= UTOP) || PGOFF(va)) // 溢出或未对齐
        return -E_INVAL;
    page_remove(env_store->env_pgdir, va); // 移除该页的映射
    return 0;
}

// Try to send 'value' to the target env 'envid'.
// If srcva < UTOP, then also send page currently mapped at 'srcva',
// so that receiver gets a duplicate mapping of the same page.
/*
 * 尝试向指定进程发送 values 值
 * 如果 srcva < UTOP，将映射在 srcva 的页面也发送，以便接受者得到同样的页面映射。
 */
// The send fails with a return value of -E_IPC_NOT_RECV if the
// target is not blocked, waiting for an IPC.
/*
 * 发送失败的话，返回 -E_IPC_NOT_RECV，表示目标未受阻
 */
// The send also can fail for the other reasons listed below.
/*
 * 发送方在下述某些情况也会失败。
 */
// Otherwise, the send succeeds, and the target's ipc fields are
// updated as follows:
//    env_ipc_recving is set to 0 to block future sends;
//    env_ipc_from is set to the sending envid;
//    env_ipc_value is set to the 'value' parameter;
//    env_ipc_perm is set to 'perm' if a page was transferred, 0 otherwise.
// The target environment is marked runnable again, returning 0
// from the paused sys_ipc_recv system call.  (Hint: does the
// sys_ipc_recv function ever actually return?)
/*
 * 否则，成功。目标进程痛心将会得到下面的值：
 * 	  env_ipc_recving被设置为0阻塞将来的发送
 * 	  env_ipc_from被设置为返送方的进程号
 * 	  env_ipc_value被设置为发送的值
 * 	  env_ipc_perm在有页传输的情况下被设置为指定的属性，否则为0
 * 目标进程被标记为可运行，从 sys_ipc_recv 的系统调用中返回0
 */
// If the sender wants to send a page but the receiver isn't asking for one,
// then no page mapping is transferred, but no error occurs.
// The ipc only happens when no errors occur.
/*
 * 如果发送方想要发送一个页面，而接收方为请求，那么不会被发送，也不会出错。
 * 内部进程通信仅发生在无错误时。
 */
// Returns 0 on success, < 0 on error.
// Errors are:
//	-E_BAD_ENV if environment envid doesn't currently exist.
//		(No need to check permissions.)
//	-E_IPC_NOT_RECV if envid is not currently blocked in sys_ipc_recv,
//		or another environment managed to send first.
//	-E_INVAL if srcva < UTOP but srcva is not page-aligned.
//	-E_INVAL if srcva < UTOP and perm is inappropriate
//		(see sys_page_alloc).
//	-E_INVAL if srcva < UTOP but srcva is not mapped in the caller's
//		address space.
//	-E_INVAL if (perm & PTE_W), but srcva is read-only in the
//		current environment's address space.
//	-E_NO_MEM if there's not enough memory to map srcva in envid's
//		address space.
/*
 * 返回0表示成功，小于0错误：
 * 	-E_BAD_ENV——进程不存在，不必进行权限检查
 * 	-E_IPC_NOT_RECV——指定进程尚未准备好接受，或者另外一个进程尝试先发送
 * 	-E_INVAL——srcva < UTOP 但未对齐
 * 	          srcva < UTOP 而且 perm 不正确
 * 			  srcva < UTOP 但 srcva 未映射到调用者的地址空间
 * 			  可写权限，但 srcva 在当前进程下只是可读的
 *  -E_NO_MEM——无可用内存供 srcva 映射
 *
 */
static int
sys_ipc_try_send(envid_t envid, uint32_t value, void *srcva, unsigned perm)
{
	// LAB 4: Your code here.
//	panic("sys_ipc_try_send not implemented");
    struct Env *rec_env; // 进程定义
    unsigned flag = PTE_P | PTE_U; // 当前及用户级别标记
    // 检查进程是否存在
    if (envid2env(envid, &rec_env, false) < 0)
        return -E_BAD_ENV;
    // 检查接受进程是否准备好接收
    if (rec_env->env_ipc_recving == false)
        return -E_IPC_NOT_RECV;
    rec_env->env_ipc_perm = 0; // 默认为0，有页传送，设置为指定属性
    if ((uintptr_t)srcva < UTOP) { // 处于 UTOP 之下，发送一个页
        if (PGOFF(srcva)) // 检查是否对齐
            return -E_INVAL;
        // 属性不正确 #define PTE_SYSCALL	(PTE_AVAIL | PTE_P | PTE_W | PTE_U) 除了这几位，其他不能设置，见sys_page_alloc
        if ((perm & ~(PTE_SYSCALL)) || ((perm & flag) != flag)) // 检查指定属性是否正确，
            return -E_INVAL;
        if (user_mem_check(curenv, (const void *)srcva, PGSIZE, PTE_U) < 0) // 检查是否已经映射到当前进程-调用者的地址空间
            return -E_INVAL;
        if (user_mem_check(curenv, (const void *)srcva, PGSIZE, PTE_U | PTE_W) < 0) // 可写权限，但当前是只读的
            return -E_INVAL;
        if ((uintptr_t)(rec_env->env_ipc_dstva) < UTOP) { // 判断是否返送页
            rec_env->env_ipc_perm = perm; // 赋予权限
            struct PageInfo *pp = page_lookup(curenv->env_pgdir, srcva, 0); // 找到指定的页
            if (page_insert(rec_env->env_pgdir, pp, rec_env->env_ipc_dstva,  perm) < 0) // 将该页添加到接收进程的地址空间
                return -E_NO_MEM;
        }
    }
    // 发送 value
    rec_env->env_ipc_recving = false;
    rec_env->env_ipc_from = curenv->env_id;
    rec_env->env_ipc_value = value;
    rec_env->env_status = ENV_RUNNABLE;
    rec_env->env_tf.tf_regs.reg_eax = 0; // 从 sys_ipc_recv 的系统调用中返回0
    return 0;
}

// Block until a value is ready.  Record that you want to receive
// using the env_ipc_recving and env_ipc_dstva fields of struct Env,
// mark yourself not runnable, and then give up the CPU.
//
// If 'dstva' is < UTOP, then you are willing to receive a page of data.
// 'dstva' is the virtual address at which the sent page should be mapped.
//
// This function only returns on error, but the system call will eventually
// return 0 on success.
// Return < 0 on error.  Errors are:
//	-E_INVAL if dstva < UTOP but dstva is not page-aligned.
/*
 * 接收进程一直阻塞，直到可以接收。
 * 记录下来，你想要使用 env_ipc_recving and env_ipc_dstva fields of struct Env
 * 进行接收，将自己标记为不可运行，之后放弃CPU。
 *
 * 如果 dstva < UTOP，表示你想要收到一页数据，dstva 就是这一页的虚拟地址
 *
 * 该函数仅在发生错误时返回，但是系统调用最终成功时会返回0.
 * 错误返回<0，
 *  -E_INVAL—— dstva < UTOP，但 dstva 未对齐
 */
static int
sys_ipc_recv(void *dstva)
{
	// LAB 4: Your code here.
//	panic("sys_ipc_recv not implemented");
    if((dstva < (void *)UTOP) && PGOFF(dstva)) // dstva < UTOP，表示想要收到一个页，但 dstva 未对齐
        return -E_INVAL;
    curenv->env_ipc_recving = true;
    curenv->env_ipc_dstva = dstva;
    curenv->env_status = ENV_NOT_RUNNABLE;
//    sched_yield(); // 不能存在
    return 0;
}

// Dispatches to the correct kernel function, passing the arguments.
int32_t
syscall(uint32_t syscallno, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4, uint32_t a5)
{
	// Call the function corresponding to the 'syscallno' parameter.
	// Return any appropriate return value.
	// LAB 3: Your code here.

//	panic("syscall not implemented");

    switch (syscallno) {
        case SYS_cputs:
            sys_cputs((const char *) a1, (size_t) a2);
            return 0;
        case SYS_cgetc:
            return sys_cgetc();
        case SYS_getenvid:
            return sys_getenvid();
        case SYS_env_destroy:
            return sys_env_destroy((envid_t)a1);
        case SYS_yield:
            sys_yield();
            return 0;
        case SYS_exofork:
            return sys_exofork();
        case SYS_env_set_status:
        	return sys_env_set_status((envid_t)a1, (int)a2);
        case SYS_page_alloc:
            return sys_page_alloc((envid_t)a1, (void *)a2, (int)a3);
        case SYS_page_map:
            return sys_page_map((envid_t)a1, (void *)a2, (envid_t)a3, (void *)a4, (int)a5);
        case SYS_page_unmap:
            return sys_page_unmap((envid_t)a1, (void *)a2);
        case SYS_env_set_pgfault_upcall:
        	return sys_env_set_pgfault_upcall((envid_t)a1, (void*)a2);
        case SYS_ipc_try_send:
            return sys_ipc_try_send((envid_t)a1, (uint32_t)a2, (void *)a3, (unsigned)a4);
        case SYS_ipc_recv:
            return sys_ipc_recv((void *)a1);
		case SYS_env_set_trapframe :
			return sys_env_set_trapframe((envid_t) a1, (struct Trapframe*) a2);
        default:
            return -E_INVAL;
	}
}

