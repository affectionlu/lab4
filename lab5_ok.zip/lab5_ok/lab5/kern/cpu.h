
#ifndef JOS_INC_CPU_H
#define JOS_INC_CPU_H

#include <inc/types.h>
#include <inc/memlayout.h>
#include <inc/mmu.h>
#include <inc/env.h>

// Maximum number of CPUs 8
#define NCPU  8

// Values of status in struct Cpu
// CPU使用状态，未使用、使用、停用
enum {
	CPU_UNUSED = 0,
	CPU_STARTED,
	CPU_HALTED,
};

// Per-CPU state
// 单个CPU状态
struct CpuInfo {
	uint8_t cpu_id;                 // Local APIC ID; index into cpus[] below. APIC ID，被哪个中断占用
	volatile unsigned cpu_status;   // The status of the CPU. CPU状态
	struct Env *cpu_env;            // The currently-running environment. 当前进程
	struct Taskstate cpu_ts;        // Used by x86 to find stack for interrupt. 任务段，用于寻找内核堆栈
};

// Initialized in mpconfig.c
// 保存全部CPU的信息
extern struct CpuInfo cpus[NCPU];
extern int ncpu;                    // Total number of CPUs in the system
extern struct CpuInfo *bootcpu;     // The boot-strap processor (BSP)
extern physaddr_t lapicaddr;        // Physical MMIO address of the local APIC

// Per-CPU kernel stacks
// 各个COU的堆栈空间
/*
 * 在 Lab 2 中，你把 bootstack 指向的内存映射到了紧邻 KSTACKtOP 的下面。
 * 相似地，在本次实验中，你会把每个CPU的内核堆栈映射到这里，
 * 同时，在每个内核堆栈之间会留有一段 守护页 作为它们之间的缓冲区。
 * CPU 0 的堆栈仍然会从 KSTACKTOP 向下生长，
 * CPU 1的堆栈会在 CPU0 栈底的 KSTKGAP 以下开始向下生长，
 * 以此类推。
 */
extern unsigned char percpu_kstacks[NCPU][KSTKSIZE];

int cpunum(void);
// 宏定义 thiscpu 是访问当前 CPU 的 struct CpuInfo 结构的简写
#define thiscpu (&cpus[cpunum()])

void mp_init(void);
void lapic_init(void);
void lapic_startap(uint8_t apicid, uint32_t addr);
void lapic_eoi(void);
void lapic_ipi(int vector);

#endif
