// Simple command-line kernel monitor useful for
// controlling the kernel and exploring the system interactively.

// new in lab3
#include <inc/stdio.h>
#include <inc/string.h>
#include <inc/memlayout.h>
#include <inc/assert.h>
#include <inc/x86.h>

#include <kern/console.h>
#include <kern/monitor.h> // in lab2
#include <kern/kdebug.h>
#include <kern/trap.h>
#include <kern/env.h>
// end new in lab3

#define CMDBUF_SIZE	80	// enough for one VGA text line

#define WHITESPACE "\t\r\n "
#define MAXARGS 16

struct Command {
	const char *name;
	const char *desc;
	// return -1 to force monitor to exit
	int (*func)(int argc, char** argv, struct Trapframe* tf);
};

/***** Implementations of basic Jos monitor ******/

static struct Command commands[] = {
	{ "help", "Display this list of commands", mon_help },
	{ "kerninfo", "Display information about the kernel", mon_kerninfo },
	{ "backtrace", "Display a listing of function call frames", mon_backtrace },
	{ "jdb", "Run JOS debugger", mon_jdb},
};
#define NCOMMANDS (sizeof(commands)/sizeof(commands[0]))

/***** Implementations of basic kernel monitor commands *****/

int
mon_help(int argc, char **argv, struct Trapframe *tf)
{
	int i;

	for (i = 0; i < NCOMMANDS; i++)
		cprintf("%s - %s\n", commands[i].name, commands[i].desc);
	return 0;
}

int
mon_kerninfo(int argc, char **argv, struct Trapframe *tf)
{
	extern char _start[], entry[], etext[], edata[], end[];

	cprintf("Special kernel symbols:\n");
	cprintf("  _start                  %08x (phys)\n", _start);
	cprintf("  entry  %08x (virt)  %08x (phys)\n", entry, entry - KERNBASE);
	cprintf("  etext  %08x (virt)  %08x (phys)\n", etext, etext - KERNBASE);
	cprintf("  edata  %08x (virt)  %08x (phys)\n", edata, edata - KERNBASE);
	cprintf("  end    %08x (virt)  %08x (phys)\n", end, end - KERNBASE);
	cprintf("Kernel executable memory footprint: %dKB\n",
		ROUNDUP(end - entry, 1024) / 1024);
	return 0;
}

int
mon_backtrace(int argc, char **argv, struct Trapframe *tf)
{
	unsigned int ebp = read_ebp(); // 获得调用当前函数的函数的ebp值
	unsigned int end_ebp = 0xf010fff8;
	cprintf("%s\n", "Stack backtrace:");
	while(ebp != 0x0){
		unsigned int eip = *(int *)(ebp + 4);
		unsigned int argu_1 = *(int *)(ebp + 8);
		unsigned int argu_2 = *(int *)(ebp + 12);
		unsigned int argu_3 = *(int *)(ebp + 16);
		unsigned int argu_4 = *(int *)(ebp + 20);
		unsigned int argu_5 = *(int *)(ebp + 24);
		struct Eipdebuginfo info; // 存储eip对应函数的信息
		debuginfo_eip(eip, &info); // 查询eip对应函数的信息
		cprintf("    ebp %08x eip %08x args %08x %08x %08x %08x %08x\n", 
			ebp, eip, argu_1, argu_2, argu_3, argu_4, argu_5
		);
		cprintf("    FILE: %s:%d: %.*s+%d\n", info.eip_file, info.eip_line, info.eip_fn_namelen, info.eip_fn_name, eip - info.eip_fn_addr);
		ebp = *(int *)ebp;
	}
	return 0;
}

// 命令行进入debug模式
int
mon_jdb(int argc, char **argv, struct Trapframe *tf) {
	monitor_jdb(tf);
	return -1;
}

/***** Kernel monitor command interpreter *****/

/*
 * 控制台命令执行
 */
static int
runcmd(char *buf, struct Trapframe *tf)
{
	int argc;
	char *argv[MAXARGS];
	int i;

	// Parse the command buffer into whitespace-separated arguments
	argc = 0;
	argv[argc] = 0; // 存储命令名称
	while (1) {
		// gobble whitespace
		while (*buf && strchr(WHITESPACE, *buf))
			*buf++ = 0;
		if (*buf == 0)
			break;

		// save and scan past next arg
		if (argc == MAXARGS-1) {
			cprintf("Too many arguments (max %d)\n", MAXARGS);
			return 0;
		}
		argv[argc++] = buf;
		while (*buf && !strchr(WHITESPACE, *buf))
			buf++;
	}
	argv[argc] = 0;

	// Lookup and invoke the command
	if (argc == 0)
		return 0;
	for (i = 0; i < NCOMMANDS; i++) {
		if (strcmp(argv[0], commands[i].name) == 0)
			return commands[i].func(argc, argv, tf);
	}
	cprintf("Unknown command '%s'\n", argv[0]);
	return 0;
}

void
monitor(struct Trapframe *tf)
{
	char *buf;

	cprintf("Welcome to the JOS kernel monitor!\n");
	cprintf("Type 'help' for a list of commands.\n");

	if (tf != NULL)
		print_trapframe(tf);

	while (1) {
		buf = readline("K> ");
		if (buf != NULL)
			if (runcmd(buf, tf) < 0)
				break;
	}
}

/***** Implementations of basic Jos user debug monitor ******/

static struct Command commands_debug[] = {
		{ "help", "Display this list of commands", jdb_help },
		{ "si", "Single Step", jdb_si },
		{ "c", "Continue execution", jdb_continue },
		{ "quit", "Exit debugger", jdb_quit },
};

#define NDEBUGCOMMANDS (sizeof(commands_debug)/sizeof(commands_debug[0]))

/***** Implementations of basic Jos user debug commands *****/

int
jdb_help(int argc, char **argv, struct Trapframe *tf) {
	int i;

	for (i = 0; i < NDEBUGCOMMANDS; i++)
		cprintf("%s - %s\n", commands_debug[i].name, commands_debug[i].desc);
	return 0;
}

int
jdb_si(int argc, char **argv, struct Trapframe *tf) {
	if (tf == NULL || !(tf->tf_trapno == T_BRKPT || tf->tf_trapno == T_DEBUG))
		return -1;
	tf->tf_eflags |= FL_TF; // 陷阱标志位，执行一条指令，再次进入int 3
	return -1;
}
int
jdb_continue(int argc, char **argv, struct Trapframe *tf) {
	if (tf == NULL || !(tf->tf_trapno == T_BRKPT || tf->tf_trapno == T_DEBUG))
		return -1;
	tf->tf_eflags &= ~FL_TF; // 取消陷阱标志位
	return -1; // 一直返回直到用户态
}
int
jdb_quit(int argc, char **argv, struct Trapframe *tf) {
	if (tf == NULL || !(tf->tf_trapno == T_BRKPT || tf->tf_trapno == T_DEBUG))
		return -1;
	tf->tf_eflags &= ~FL_TF; // 取消陷阱标志位
	return -1; // 一直返回直到用户态
}

/***** User denug monitor command interpreter *****/

/*
 * 调试命令执行
 */
static int
runcmd_jdb(char *buf, struct Trapframe *tf)
{
	int argc;
	char *argv[MAXARGS];
	int i;
	// Parse the command buffer into whitespace-separated arguments
	argc = 0;
	argv[argc] = 0;
	while (1) {
		// gobble whitespace
		while (*buf && strchr(WHITESPACE, *buf))
			*buf++ = 0;
		if (*buf == 0)
			break;
		// save and scan past next arg
		if (argc == MAXARGS-1) {
			cprintf("Too many arguments (max %d)\n", MAXARGS);
			return 0;
		}
		argv[argc++] = buf;
		while (*buf && !strchr(WHITESPACE, *buf))
			buf++;
	}
	argv[argc] = 0;
	// Lookup and invoke the command
	if (argc == 0)
		return 0;
	for (i = 0; i < NDEBUGCOMMANDS; i++) {
		if (strcmp(argv[0], commands_debug[i].name) == 0)
			return commands_debug[i].func(argc, argv, tf);
	}
	cprintf("Unknown command '%s'\n", argv[0]);
	return 0;
}

int
monitor_jdb(struct Trapframe *tf) {
    char *buf;
    cprintf("Welcome to the JOS debug monitor!\n");
    if (tf)
        cprintf("=> 0x%08x\n", tf->tf_eip);
    while(1) {
        buf = readline("(jdb) ");
        if (buf)
            if (runcmd_jdb(buf, tf) < 0)
                break;
    }
    return -1; // return 0?
}
