// implement fork from user space

#include <inc/string.h>
#include <inc/lib.h>

// PTE_COW marks copy-on-write page table entries.
// It is one of the bits explicitly allocated to user processes (PTE_AVAIL).
// 标记写时赋值页表入口点，是PTE_AVAIL中分配的一些位
#define PTE_COW		0x800

//
// Custom page fault handler - if faulting page is copy-on-write,
// map in our own private writable copy.
/*
 * 自定义缺页处理函数——如果缺页是写时赋值的情况，映射进我们私有的可写的复制页面中
 */
static void
pgfault(struct UTrapframe *utf)
{
	void *addr = (void *) utf->utf_fault_va;
	uint32_t err = utf->utf_err;
	int r;

	// Check that the faulting access was (1) a write, and (2) to a
	// copy-on-write page.  If not, panic.
	// Hint:
	//   Use the read-only page table mappings at uvpt
	//   (see <inc/memlayout.h>).
	/*
	 * 检查缺页访问是否是可写的、或者写时复制的，否则panic
	 * 提示：
	 * 		使用uvpt中的只读页表 UVPT
	 */
	// LAB 4: Your code here.
	// PGNUM：标志位
	// PDX：页目录索引
	// uvpd：VA of current page directory
	// uvpt：VA of "virtual page table"
    if (!(
        (err & FEC_WR) && (uvpd[PDX(addr)] & PTE_P) &&
        (uvpt[PGNUM(addr)] & PTE_P) && (uvpt[PGNUM(addr)] & PTE_COW)
    ))
        panic("Neither the fault is a write nor copy-on-write page.\n");
	// Allocate a new page, map it at a temporary location (PFTEMP),
	// copy the data from the old page to the new page, then move the new
	// page to the old page's address.
	// Hint:
	//   You should make three system calls.
	/*
	 * 分配一个新页，映射到一个临时的位置 PFTEMP，将数据也拷贝进去，
	 * 然后将新页地址移动到旧页地址。
	 * 提示：
	 * 		你应该进行三次系统调用
	 */
	// LAB 4: Your code here.
//	panic("pgfault not implemented");
    envid_t envid = sys_getenvid();
    if((r = sys_page_alloc(envid, PFTEMP, PTE_U | PTE_P | PTE_W)) < 0) // 分配新页
        panic("sys_page_alloc: %e\n", r);
    addr = ROUNDDOWN(addr, PGSIZE); // 对齐
    memcpy((void *)PFTEMP, addr, PGSIZE); // 拷贝数据
    if ((r = sys_page_map(envid, (void *)PFTEMP, envid, addr, PTE_P | PTE_U | PTE_W)) < 0) // 新地址进行映射
        panic("sys_page_map: %e\n", r);
    if ((r = sys_page_unmap(envid, (void *)PFTEMP)) < 0) // 临时地址取消映射
        panic("sys_page_unmap: %e\n", r);
}

//
// Map our virtual page pn (address pn*PGSIZE) into the target envid
// at the same virtual address.  If the page is writable or copy-on-write,
// the new mapping must be created copy-on-write, and then our mapping must be
// marked copy-on-write as well.  (Exercise: Why do we need to mark ours
// copy-on-write again if it was already copy-on-write at the beginning of
// this function?)
//
// Returns: 0 on success, < 0 on error.
// It is also OK to panic on error.
/*
 * 将虚拟页 pn(address pn*PGSIZE)映射到目标进程同样的虚拟地址，即是拷贝。
 * 如果页是可写或者写时复制的，新映射应该是写时复制的，之后原映射也必须设置为写时复制的。
 * 父进程需要知道自己的某些页是写时复制的，不能随意更改。
 *
 * 成功返回0，错误返回小于0，可以panic
 */
static int
duppage(envid_t envid, unsigned pn)
{
	int r;

	// LAB 4: Your code here.
//	panic("duppage not implemented");
    void *vaddr = (void *)(pn * PGSIZE); // 虚拟地址
    if(uvpt[pn] & PTE_SHARE){
    	if ((r = sys_page_map(0, vaddr, envid, vaddr, uvpt[pn] & PTE_SYSCALL)) < 0)
    		return r;
    }
    else if ((uvpt[pn] & PTE_W) || (uvpt[pn] & PTE_COW)) { // 可写或是写时复制的
    	if ((r = sys_page_map(0, vaddr, envid, vaddr, PTE_P | PTE_U | PTE_COW)) < 0) // 调用sys_page_map将父进程0，指定内存映射到目的子进程envid
            return r;
        if ((r = sys_page_map(0, vaddr, 0, vaddr, PTE_P | PTE_U | PTE_COW)) < 0) // 父进程本身映射为写时复制
            return r;
    } else if ((r = sys_page_map(0, vaddr, envid, vaddr, PTE_P | PTE_U)) < 0) // 简单映射
        return r;
    return 0;
}

//
// User-level fork with copy-on-write.
// Set up our page fault handler appropriately.
// Create a child.
// Copy our address space and page fault handler setup to the child.
// Then mark the child as runnable and return.
//
// Returns: child's envid to the parent, 0 to the child, < 0 on error.
// It is also OK to panic on error.
//
// Hint:
//   Use uvpd, uvpt, and duppage.
//   Remember to fix "thisenv" in the child process.
//   Neither user exception stack should ever be marked copy-on-write,
//   so you must allocate a new page for the child's user exception stack.
/*
 * 用户级别的fork函数，使用写时复制机制。
 * 1、设置缺页处理函数。
 * 2、创建一个子进程。
 * 3、将父进程的地址空间和缺页处理函数复制到子进程。
 * 4、在设置完毕返回时，将子进程标记为可运行。
 *
 * 返回子进程的进程号给父进程，0代表子进程，小于0代表错误，错误时可以panic。
 *
 * 提示：
 * 		1、使用uvpd、uvpt、duppage
 * 		2、谨记处理子进程中的thisenv
 * 		3、用户异常栈不能被标记为写时复制，你必须重新分配一个页面作为子进程的用户异常栈
 */
envid_t
fork(void)
{
	// LAB 4: Your code here.
//	panic("fork not implemented");
    envid_t cenvid;
    unsigned pn;
    int r;
    set_pgfault_handler(pgfault); // 设置父进程缺页处理函数
    if ((cenvid = sys_exofork()) < 0) // 创建子进程，如果本身已经是子进程，返回0，父进程中则返回子进程号
        return cenvid;
    if (cenvid > 0) {
    	 // 获取父进程的数据，循环调用duppage拷贝到指定进程的同样内存位置，同时设置为写时复制
        for (pn = PGNUM(UTEXT); pn < PGNUM(USTACKTOP); pn++)
            if ((uvpd[pn >> 10] & PTE_P) && (uvpt[pn] & PTE_P))
                if ((r = duppage(cenvid, pn)) < 0)
                    return r;
        // 为子进程分配用户异常栈
        if ((r = sys_page_alloc(cenvid, (void *)(UXSTACKTOP - PGSIZE), PTE_U | PTE_P | PTE_W)) < 0)
            return r;
        // 为子进程设置缺页处理函数
        extern void _pgfault_upcall(void);
        if ((r = sys_env_set_pgfault_upcall(cenvid, _pgfault_upcall)) < 0)
            return r;
       // 子进程标记为可运行
        if ((r = sys_env_set_status(cenvid, ENV_RUNNABLE)) < 0)
            return r;
        return cenvid;
    } else { // 处于子进程中，设置子进程的进程指针
        thisenv = &envs[ENVX(sys_getenvid())];
        return 0;
    }
}

// Challenge!
int
sfork(void)
{
//	panic("sfork not implemented");
//	return -E_INVAL;
	envid_t envid, thisenvid = sys_getenvid();
	int perm;
	int r;
	uint32_t i, j, pn;
	set_pgfault_handler(pgfault); // 设置缺页处理函数
	if ((envid = sys_exofork()) == 0) { // 创建子进程，如果本身已经是子进程，返回0，父进程中则返回子进程号
		thisenv = &envs[ENVX(sys_getenvid())];
		return 0;
	}
	for (i = PDX(UXSTACKTOP-PGSIZE); i >= PDX(UTEXT) ; i--) { // 父进程所有数据赋值给子进程
		if (uvpd[i] & PTE_P) { // 判断此页是否是当前进程页
			for (j = 0; j < NPTENTRIES; j++) {
				pn = PGNUM(PGADDR(i, j, 0));
				if (pn == PGNUM(UXSTACKTOP - PGSIZE)) // 用户异常栈不复制
					break;
				if (pn == PGNUM(USTACKTOP - PGSIZE)) // 正常用户栈进行复制
					 duppage(envid, pn);
				else if (uvpt[pn] & PTE_P) { // 属于当前进程的其他数据，以指定的权限进行映射，权限指定，
                                             // #define PTE_SYSCALL	(PTE_AVAIL | PTE_P | PTE_W | PTE_U) 除了这几位，其他不能设置，见sys_page_alloc
					perm = uvpt[pn] & ~(uvpt[pn] & ~(PTE_SYSCALL));
					if ((r = sys_page_map(thisenvid, (void *)(PGADDR(i, j, 0)),
							envid, (void *)(PGADDR(i, j, 0)), perm)) < 0)
						return r;
				}
			}
		}
	}
	if ((r = sys_page_alloc(envid, (void *)(UXSTACKTOP - PGSIZE), PTE_U | PTE_P | PTE_W)) < 0) // 分配异常栈
		return r;
	if ((r = sys_page_map(envid, (void *)(UXSTACKTOP - PGSIZE),
		thisenvid, PFTEMP, PTE_U | PTE_P | PTE_W)) < 0) // 建立映射关系
		return r;
	memmove((void *)(UXSTACKTOP - PGSIZE), PFTEMP, PGSIZE); // 将建立映射关系的数据移到子进程指定位置
	if ((r = sys_page_unmap(thisenvid, PFTEMP)) < 0)
		return r;
	extern void _pgfault_upcall(void); // 设置子进程缺页处理函数
	sys_env_set_pgfault_upcall(envid, _pgfault_upcall);
	if ((r = sys_env_set_status(envid, ENV_RUNNABLE)) < 0) // 标记为可运行
		return r;
	return envid;
}
