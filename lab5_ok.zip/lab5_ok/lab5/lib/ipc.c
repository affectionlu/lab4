// User-level IPC library routines

#include <inc/lib.h>

// Receive a value via IPC and return it.
// If 'pg' is nonnull, then any page sent by the sender will be mapped at
//	that address.
// If 'from_env_store' is nonnull, then store the IPC sender's envid in
//	*from_env_store.
// If 'perm_store' is nonnull, then store the IPC sender's page permission
//	in *perm_store (this is nonzero iff a page was successfully
//	transferred to 'pg').
// If the system call fails, then store 0 in *fromenv and *perm (if
//	they're nonnull) and return the error.
// Otherwise, return the value sent by the sender
//
// Hint:
//   Use 'thisenv' to discover the value and who sent it.
//   If 'pg' is null, pass sys_ipc_recv a value that it will understand
//   as meaning "no page".  (Zero is not the right value, since that's
//   a perfectly valid place to map a page.)
/*
 * 通过内部进程通信接收值，并返回它。
 * 如果 pg 非空，发送方发送的任何一个页都会被映射到该地址。
 * 如果 from_env_store 非空，将发送方的 进程号 存储到 *from_env_store。
 * 如果 perm_store 非空，将发送方发送的页权限存储到 *perm_store。
 * 如果系统调用失败，将0存储到 *fromenv 和 *perm，如果它们非空，之后返回错误。
 * 否则，返回发送法发送的值。
 *
 * 提示：
 * 	使用 thisenv 获得 value 以及发送方。
 * 	如果 pg 空，传递给 sys_ipc_recv 一个值，让他知道为空页(不为0)。
 */
int32_t
ipc_recv(envid_t *from_env_store, void *pg, int *perm_store)
{
	// LAB 4: Your code here.
//	panic("ipc_recv not implemented");
    pg = (pg == NULL ? (void *)UTOP : pg); // 空则赋予一个其他值，dstva < UTOP，表示想要收到一个页
    int r;
    if ((r = sys_ipc_recv(pg)) < 0) { // 调用失败，fanhouse错误值
        if (from_env_store != NULL)
            *from_env_store = 0;
        if (perm_store != NULL)
            *perm_store = 0;
        return r;
    }
    if (from_env_store != NULL) // 非空
        *from_env_store = thisenv->env_ipc_from;
    if (perm_store != NULL) // 非空
        *perm_store = thisenv->env_ipc_perm;
    return thisenv->env_ipc_value;
}

// Send 'val' (and 'pg' with 'perm', if 'pg' is nonnull) to 'toenv'.
// This function keeps trying until it succeeds.
// It should panic() on any error other than -E_IPC_NOT_RECV.
//
// Hint:
//   Use sys_yield() to be CPU-friendly.
//   If 'pg' is null, pass sys_ipc_try_send a value that it will understand
//   as meaning "no page".  (Zero is not the right value.)
/*
 * 发送 value ，如果页非空，和权限一块也发送给指定进程。
 * 该函数一直运行，直到成功。
 * 如果收到除了 -E_IPC_NOT_RECV 的错误，则需要 panic
 *
 * 提示：
 * 	使用 sys_yield
 * 	如果 pg 为空，赋予 sys_ipc_try_send 一个值，让他知道不发送页
 */
void
ipc_send(envid_t to_env, uint32_t val, void *pg, int perm)
{
	// LAB 4: Your code here.
//	panic("ipc_send not implemented");
    int r;
    pg = (pg == NULL ? (void *)UTOP : pg); // 赋予一个他值，和上面雷同
    while ((r = sys_ipc_try_send(to_env, val, pg, perm)) < 0) { // 未成功则继续发送
        if ( r != -E_IPC_NOT_RECV) // 非 -E_IPC_NOT_RECV 错误则panic
            panic("sys_ipc_try_send: %e\n", r);
         sys_yield();
    }
}

// Find the first environment of the given type.  We'll use this to
// find special environments.
// Returns 0 if no such environment exists.
envid_t
ipc_find_env(enum EnvType type)
{
	int i;
	for (i = 0; i < NENV; i++)
		if (envs[i].env_type == type)
			return envs[i].env_id;
	return 0;
}
