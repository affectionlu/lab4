// See COPYRIGHT for copyright information.

#ifndef JOS_INC_FS_H
#define JOS_INC_FS_H

#include <inc/types.h>
#include <inc/mmu.h>

// File nodes (both in-memory and on-disk)
// 文件结点
// Bytes per file system block - same as page size
// 文件系统块4096字节
#define BLKSIZE		PGSIZE
#define BLKBITSIZE	(BLKSIZE * 8)
// Maximum size of a filename (a single path component), including null
// Must be a multiple of 4
// 文件名字的最大长度，可以为空，且为4的整数倍
#define MAXNAMELEN	128
// Maximum size of a complete pathname, including null
// 最大路径名字长度
#define MAXPATHLEN	1024
// Number of block pointers in a File descriptor
// 文件描述符中直接块指针个数
#define NDIRECT		10
// Number of direct block pointers in an indirect block
// 间接块的间接块指针个数
#define NINDIRECT	(BLKSIZE / 4)
//最大文件大小
#define MAXFILESIZE	((NDIRECT + NINDIRECT) * BLKSIZE)

// 文件结构
struct File {
	char f_name[MAXNAMELEN];	// filename 文件名
	off_t f_size;			// file size in bytes 文件大小
	uint32_t f_type;		// file type 文件类型

	// Block pointers. 块(数据)指针
	// A block is allocated iff its value is != 0. 指针非空才允许分配，文件大小最多1034个块
	uint32_t f_direct[NDIRECT];	// direct blocks 直接块数组，共10个，40KB小文件
	uint32_t f_indirect;		// indirect block 间接块指针，大于40KB的文件，额外一个块保存1024间接磁盘块号

	// Pad out to 256 bytes; must do arithmetic in case we're compiling
	// fsformat on a 64-bit machine.
	// 保留256字节：需要算数计算，以防在64位机上编译文件格式
	uint8_t f_pad[256 - MAXNAMELEN - 8 - 4*NDIRECT - 4];
} __attribute__((packed));	// required only on some 64-bit machines

// An inode block contains exactly BLKFILES 'struct File's
// 一个结点块包含 BLKFILES
#define BLKFILES	(BLKSIZE / sizeof(struct File))

// File types
// 文件类型
#define FTYPE_REG	0	// Regular file
#define FTYPE_DIR	1	// Directory

// File system super-block (both in-memory and on-disk)
// 文件超级块
#define FS_MAGIC	0x4A0530AE	// related vaguely to 'J\0S!'

struct Super {
	uint32_t s_magic;		// Magic number: FS_MAGIC 块号
	uint32_t s_nblocks;		// Total number of blocks on disk 磁盘总块数
	struct File s_root;		// Root directory node 根结点指针
};

// Definitions for requests from clients to file system
// 客户文件请求命令定义
enum {
	FSREQ_OPEN = 1,
	FSREQ_SET_SIZE,
	// Read returns a Fsret_read on the request page
	FSREQ_READ,
	FSREQ_WRITE,
	// Stat returns a Fsret_stat on the request page
	FSREQ_STAT,
	FSREQ_FLUSH,
	FSREQ_REMOVE,
	FSREQ_SYNC
};

// 联合体——命令定义
// 分别用于执行对应的文件命令
union Fsipc {
	struct Fsreq_open {
		char req_path[MAXPATHLEN];
		int req_omode;
	} open;
	struct Fsreq_set_size {
		int req_fileid;
		off_t req_size;
	} set_size;
	struct Fsreq_read {
		int req_fileid;
		size_t req_n;
	} read;
	struct Fsret_read {
		char ret_buf[PGSIZE];
	} readRet;
	struct Fsreq_write {
		int req_fileid;
		size_t req_n;
		char req_buf[PGSIZE - (sizeof(int) + sizeof(size_t))];
	} write;
	struct Fsreq_stat {
		int req_fileid;
	} stat;
	struct Fsret_stat {
		char ret_name[MAXNAMELEN];
		off_t ret_size;
		int ret_isdir;
	} statRet;
	struct Fsreq_flush {
		int req_fileid;
	} flush;
	struct Fsreq_remove {
		char req_path[MAXPATHLEN];
	} remove;

	// Ensure Fsipc is one page
	char _pad[PGSIZE];
};

#endif /* !JOS_INC_FS_H */
